This directory contains a collection of helping-programs, that were used to create the opening-databases
and the alpha-beta-agent.

All listed programs were created with the Borland C++ Builder 5 or Codegear C++ Builder 2009.
