Load the binary version of a database and convert all positions in the huffman-format.
The new database will be stored in another file.