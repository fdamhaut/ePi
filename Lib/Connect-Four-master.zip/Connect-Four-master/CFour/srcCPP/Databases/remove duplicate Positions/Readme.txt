This small program removes all duplicate positions out of the early version of 
the databases that are equal when mirrored at the center column.