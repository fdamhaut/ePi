Load the binary version of a database and convert all positions in the huffman-format.
The new database will be stored in another file. Works only for the 12-ply-database with exact distances.