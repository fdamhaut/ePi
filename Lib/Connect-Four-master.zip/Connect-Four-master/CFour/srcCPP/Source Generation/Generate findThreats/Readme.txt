This little cpp-program generates the findThreats-method for the Alpha-Beta-Agent. This is done, because
this method has to be very efficient and can't be written from hand because it is to long.