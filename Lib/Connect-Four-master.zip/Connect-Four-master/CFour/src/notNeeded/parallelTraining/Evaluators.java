package parallelTraining;

import c4.AlphaBetaAgent;

import competition.Evaluate;

public class Evaluators {
	// Referee
	private AlphaBetaAgent[] alphaBetaStdList = null;

	// Evaluation for TD-Agents
	private Evaluate[] evalList;

	Evaluators(int numEvaluators) {

	}
}
