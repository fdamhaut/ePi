package agentIO;

public interface IGetProgress {
	 public IOProgress getProgess() ;
}
